EYA'S NAIL — WEBSITE REDESIGN + INSTALLABLE WEB APP

Package contents
- index.html: updated frontend, based on the latest direct-Telegram booking version.
- manifest.webmanifest + service-worker.js: enables install-to-home-screen behavior (PWA).
- icons/: phone app icons.
- eyas-nail-logo.png: original logo asset (kept for compatibility).
- eyas-nail-logo-compact.webp: smaller logo used in the new hero photo card.

UPLOAD STEPS
1. Back up the current repository's index.html.
2. Upload/replace index.html in the same repository root, next to eyas-nail-logo.png.
3. Upload manifest.webmanifest and service-worker.js to the repository root.
4. Upload the entire icons folder and eyas-nail-logo-compact.webp to the repository root.
5. Commit the changes. GitHub Pages should publish the new website automatically.
6. Open the HTTPS website, scroll down, and use the rose/gold “Install Eya's Nail” button.

IMPORTANT
- Do not replace admin.html or the Python bot for this visual/PWA change.
- The current API_BASE and direct Telegram booking code are preserved from the latest frontend file.
- This is an installable web app (PWA), not a downloadable Android APK. Android browsers may show a native install prompt. On iPhone, use Safari → Share → Add to Home Screen.
- Install/shortcuts and the static shell can work offline in part, but booking, Telegram, external photos, and live API features still need internet.
- Test booking, Amharic toggle, galleries and install behavior after publishing. The hero uses an existing Pexels image URL already represented in the site's current photo gallery. If you want a completely local hero photo, upload the final approved salon photo and I can wire it in without changing the translations.
